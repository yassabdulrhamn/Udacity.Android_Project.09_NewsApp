package com.example.ranyass.newsapp_stage1;


import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;

public class CustomAdapter extends BaseAdapter {

    HashMap<Integer, ArrayList<String>> moviesHashMap;
    ArrayList<Bitmap> bitmapArray;
    LayoutInflater inflter;

    public CustomAdapter(Context applicationContext,HashMap moviesHashMap,ArrayList<Bitmap> bitmapArray) {
        inflter = (LayoutInflater.from(applicationContext));
        this.moviesHashMap = moviesHashMap;
        this.bitmapArray = bitmapArray;
    }

    @Override
    public int getCount() {
        return moviesHashMap.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        view = inflter.inflate(R.layout.activity_listview_item, null);
        TextView texMovieName = (TextView) view.findViewById(R.id.texMovieName);
        texMovieName.setText(moviesHashMap.get(i).get(0).toString());

        TextView texMovieOverview = (TextView) view.findViewById(R.id.texMovieOverview);
        texMovieOverview.setText(moviesHashMap.get(i).get(1).toString());

        TextView texReleaseDate = (TextView) view.findViewById(R.id.texReleaseDate);
        texReleaseDate.setText(moviesHashMap.get(i).get(3).toString());

        ImageView imgMoviePoster = (ImageView) view.findViewById(R.id.imgMoviePoster);
        imgMoviePoster.setImageBitmap(bitmapArray.get(i));

        return view;
    }

}
