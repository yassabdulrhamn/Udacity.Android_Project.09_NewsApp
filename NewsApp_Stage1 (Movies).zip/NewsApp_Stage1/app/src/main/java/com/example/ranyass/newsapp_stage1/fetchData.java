package com.example.ranyass.newsapp_stage1;


import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;

public class fetchData extends AsyncTask<Void,Void,Void> {
    String data = "";
    String dataParsed;
    JSONArray jsonArray;
    HashMap<Integer, ArrayList<String>> moviesHashMap;
    ArrayList<Bitmap> bitmapArray = new ArrayList();
    Bitmap Imagebitmap;
    String ImageUrl = "https://image.tmdb.org/t/p/w300_and_h450_bestv2";
    ProgressDialog dialog;

    private ListView listView;

    private Context context;

    public fetchData(ListView listView,Context context){
        this. listView = listView;
        this.context = context;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        dialog = new ProgressDialog(context);
        dialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
        dialog.setMessage("Loading. Please wait...");
        dialog.setIndeterminate(true);
        dialog.setCanceledOnTouchOutside(false);

        dialog.show();
    }

    @Override
    protected Void doInBackground(Void... voids) {

        moviesHashMap = new HashMap<>();
        try
        {

            URL url = new URL("https://api.themoviedb.org/3/discover/movie?api_key=31451ab7e7020eb2dcd2bcf2c2b25be1&language=en-US&include_adult=false&include_video=false&page=1");

            HttpURLConnection httpURLConnection = (HttpURLConnection) url.openConnection();

            httpURLConnection.setReadTimeout(10000);
            httpURLConnection.setConnectTimeout(15000);
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.connect();

            InputStream inputStream = httpURLConnection.getInputStream();
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
            String line="";

            while(line!=null)
            {
              line = bufferedReader.readLine();
              data = data + line;
            }

            JSONObject jsonObject = new JSONObject(data);
            jsonArray = jsonObject.getJSONArray("results");

            //dataParsed=jsonArray.getString(5);
            for(int i=0;i<jsonArray.length();i++)
            {
                final ArrayList<String> appleDefs = new ArrayList<>();
                JSONObject jsonObject2 = jsonArray.getJSONObject(i);
                appleDefs.add(jsonObject2.getString("title").toString());
                appleDefs.add(jsonObject2.getString("overview").toString());
                appleDefs.add(jsonObject2.getString("vote_average").toString());
                appleDefs.add(jsonObject2.getString("release_date").toString());
                appleDefs.add(jsonObject2.getString("poster_path").toString());
                moviesHashMap.put(i, appleDefs);

                try {
                    Imagebitmap = BitmapFactory.decodeStream((InputStream)new URL(ImageUrl+jsonObject2.getString("poster_path").toString()).getContent());

                } catch (Exception e) {
                    e.printStackTrace();
                }

                bitmapArray.add(Imagebitmap);
            }
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }
        dataParsed=moviesHashMap.get(1).get(0).toString();
        return null;
    }

    @Override
    protected void onPostExecute(Void aVoid) {
        super.onPostExecute(aVoid);

        dialog.dismiss();

        CustomAdapter CustomAdapter = new CustomAdapter(context.getApplicationContext(),moviesHashMap,bitmapArray);
        listView.setAdapter(CustomAdapter);
    }
}
